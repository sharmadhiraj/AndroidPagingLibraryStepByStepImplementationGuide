package com.sharmadhiraj.androidpaginglibrarystepbystepimplementationguide

enum class State {
    DONE, LOADING, ERROR
}